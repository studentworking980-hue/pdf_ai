# EvoForge --- Agentic AI SDLC Automation Platform

EvoForge is an agentic software-development lifecycle (SDLC) automation
platform built with **CrewAI**, a **local Ollama LLM**, **pytest**,
**GitPython**, **NetworkX**, and a requirement traceability graph.

The platform takes natural-language client requirements and automates
the major SDLC stages:

``` text
Client Requirements
        ↓
Requirements Analysis
        ↓
SRS Generation
        ↓
Software Architecture
        ↓
Task Planning
        ↓
Code Generation
        ↓
Test Generation
        ↓
Pytest Execution
        ↓
Agentic Debugging / Recovery
        ↓
Traceability + Git Versioning
```

A dedicated evaluation layer measures the behavior and performance of
the agentic pipeline without changing the underlying SDLC agent logic.

------------------------------------------------------------------------

## 1. Main Features

-   Requirements-driven software generation
-   CrewAI-based SDLC agents
-   Local Ollama LLM support
-   SRS, design, task, code, test, and documentation generation
-   Automated pytest execution
-   Agentic debugging and recovery loop
-   Requirement traceability graph
-   Git versioning and commit history
-   Incremental requirement-change propagation
-   Automatic AI-agent evaluation
-   Terminal evaluation report
-   Automatic PDF evaluation report
-   Evaluation history stored as JSON Lines
-   Streamlit interface
-   Repeated evaluation runs for reliability and P95 latency

------------------------------------------------------------------------

## 2. Technology Stack

  Component                   Technology
  --------------------------- ---------------------
  Programming Language        Python
  Agent Framework             CrewAI
  Local LLM                   Ollama
  Default Model               `llama3.2:latest`
  Web UI                      Streamlit
  Testing                     pytest
  Graph / Traceability        NetworkX
  Version Control             GitPython
  Data Validation             Pydantic
  Environment Configuration   python-dotenv
  Evaluation Report           Built-in PDF writer

The project is designed to work with a local Ollama deployment, so an
external LLM API is not required for the normal workflow.

------------------------------------------------------------------------

## 3. Project Structure

``` text
project/
│
├── main.py
├── app.py
├── requirements.txt
├── environment.yml
├── .env
├── .env.example
├── EVALUATION.md
│
├── agents/
│   ├── __init__.py
│   ├── sdlc_crew.py
│   └── prompt_templates.py
│
├── core/
│   ├── __init__.py
│   ├── git_manager.py
│   ├── llm.py
│   ├── project_store.py
│   ├── runner.py
│   └── traceability.py
│
├── config/
│   ├── __init__.py
│   └── settings.py
│
├── evaluation/
│   ├── __init__.py
│   ├── tracer.py
│   ├── metrics.py
│   ├── report.py
│   ├── pdf_writer.py
│   └── session.py
│
├── tests/
│   ├── __init__.py
│   ├── test_evaluation.py
│   ├── test_pipeline.py
│   ├── test_runner.py
│   └── test_traceability.py
│
├── demo/
│   └── run_demo.py
│
├── projects/
│   └── <generated projects>
│
└── evaluation_reports/
    ├── history.jsonl
    └── <project>/
        └── evaluation_<mode>_<timestamp>.pdf
```

------------------------------------------------------------------------

# 4. Requirements

Install:

-   Python 3.10+ recommended
-   Ollama
-   Git
-   pip
-   virtual environment or Conda

The Python dependencies are listed in:

``` text
requirements.txt
```

------------------------------------------------------------------------

# 5. Installation

## 5.1 Create a Conda environment

``` bash
conda create -n evoforge python=3.11 -y
conda activate evoforge
```

Or use an existing Python virtual environment.

## 5.2 Install dependencies

``` bash
pip install -r requirements.txt
```

------------------------------------------------------------------------

# 6. Configure Ollama

Start Ollama and verify that it is available:

``` bash
ollama list
```

The default configuration is:

``` text
MODEL_NAME=llama3.2:latest
OLLAMA_BASE_URL=http://localhost:11434
```

Verify the Ollama API:

``` bash
curl http://localhost:11434/api/tags
```

If a different model is installed, configure it in `.env`:

``` env
MODEL_NAME=your_model_name
OLLAMA_BASE_URL=http://localhost:11434
```

------------------------------------------------------------------------

# 7. Environment Configuration

The project reads configuration from `.env`.

Example:

``` env
MODEL_NAME=llama3.2:latest
OLLAMA_BASE_URL=http://localhost:11434
PROJECTS_DIR=projects
REPORTS_DIR=reports

EVAL_DIR=evaluation_reports

# Estimated local-compute cost
EVAL_COST_PER_HOUR=0.50
EVAL_COST_PER_1K_TOKENS=0.0
```

### Evaluation cost note

Local Ollama does not have a normal API billing charge.

Therefore, `Cost per Successful Task` is an **estimated cost** based on
the configured local-compute and optional token rates.

Adjust the values to match your hardware and accounting assumptions.

------------------------------------------------------------------------

# 8. Running the Project

## 8.1 Create a new project

Basic command:

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator with add, subtract, multiply and divide functions."
```

The requirements can also be provided as a file:

``` bash
python main.py create \
    --name calculator \
    --requirements requirements.txt
```

If the supplied path exists, the application reads the file contents as
the requirements.

------------------------------------------------------------------------

## 8.2 Create a project with detailed requirements

Example:

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator.
1. add(a, b): Returns the sum.
2. subtract(a, b): Returns a minus b.
3. multiply(a, b): Returns the product.
4. divide(a, b): Returns the quotient.
5. divide must raise ValueError when b is zero."
```

Evaluation is enabled by default.

------------------------------------------------------------------------

# 9. Running Evaluation

The evaluation layer runs automatically for normal `create` and `change`
commands.

Use:

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator with add, subtract, multiply and divide."
```

The execution flow is:

``` text
SDLC Pipeline
      ↓
Evaluation Trace
      ↓
Metric Calculation
      ↓
Terminal Report
      ↓
PDF Report
      ↓
Evaluation History
```

Do not add `--no-eval` if you want the evaluation metrics.

------------------------------------------------------------------------

# 10. Repeated Evaluation

Repeated runs are important for **Reliability** and **P95 Latency**.

Run the same task five times:

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator with add, subtract, multiply and divide." \
    --repeat 5
```

For a more meaningful experiment:

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator with add, subtract, multiply and divide." \
    --repeat 10
```

Each run is evaluated separately and added to the evaluation history.

------------------------------------------------------------------------

# 11. Requirement Changes

Existing projects can receive updated requirements:

``` bash
python main.py change \
    --name calculator \
    --requirements updated_requirements.txt
```

Evaluation is also performed automatically for this operation.

Repeated requirement-change evaluation is supported:

``` bash
python main.py change \
    --name calculator \
    --requirements updated_requirements.txt \
    --repeat 5
```

------------------------------------------------------------------------

# 12. Evaluate an Existing Project

An already generated project can be audited without running the LLM
pipeline again:

``` bash
python main.py evaluate --name calculator
```

This evaluates the saved project artifacts and runs its existing pytest
suite.

Because this mode does not execute the full agent trajectory, metrics
that require live pipeline traces may be reported as `N/A`.

------------------------------------------------------------------------

# 13. Run Tests

Run the project's automated tests:

``` bash
pytest
```

For a concise output:

``` bash
pytest -q
```

The evaluation framework includes its own tests:

``` text
tests/test_evaluation.py
```

along with the existing pipeline, runner, and traceability tests.

------------------------------------------------------------------------

# 14. Streamlit Application

Launch the graphical interface:

``` bash
streamlit run app.py
```

The application provides:

-   New Project
-   Requirement Change
-   Traceability & Impact
-   SDLC Artifacts
-   Test Execution & Debug
-   Git Versioning

After an evaluated run, the application also displays the latest
evaluation report and provides a PDF download button.

------------------------------------------------------------------------

# 15. Evaluation Metrics

The evaluation layer calculates the following 12 metrics.

  -----------------------------------------------------------------------
  \#                      Metric                  Formula / Project
                                                  Definition
  ----------------------- ----------------------- -----------------------
  1                       Task Success Rate       Successful tasks /
                                                  total tasks × 100

  2                       Task Completion Rate    Satisfied requirements
                                                  / total requirements ×
                                                  100

  3                       Accuracy                Passed results /
                                                  (passed + failed +
                                                  errors) × 100

  4                       Completeness            Requirements with SRS +
                                                  Design + code + test
                                                  evidence / total
                                                  requirements × 100

  5                       Groundedness            Supported claims /
                                                  evaluated claims × 100

  6                       Hallucination Rate      Unsupported claims /
                                                  evaluated claims × 100

  7                       Tool Selection Accuracy Correct workflow/tool
                                                  decisions / total
                                                  decisions × 100

  8                       Tool Call Success Rate  Successful recorded
                                                  operations / total
                                                  operations × 100

  9                       Recovery Rate           Recovered failures /
                                                  recoverable failures ×
                                                  100

  10                      Reliability             Successful repeated
                                                  runs / total runs × 100

  11                      P95 Latency             95th-percentile
                                                  end-to-end pipeline
                                                  completion time

  12                      Cost per Successful     Total estimated
                          Task                    evaluation cost /
                                                  successful tasks
  -----------------------------------------------------------------------

------------------------------------------------------------------------

# 16. Metric Implementation in EvoForge

## 16.1 Task Success Rate

A task is considered successful when:

1.  The pipeline finishes without an exception.
2.  The generated project exists.
3.  The final pytest run passes.

``` text
TSR = Successful Tasks / Total Tasks × 100
```

------------------------------------------------------------------------

## 16.2 Task Completion Rate

Requirements are extracted from the client requirement text.

A requirement is considered satisfied when the expected functionality
has:

-   corresponding generated code
-   test coverage
-   passing test evidence

``` text
Completion Rate =
Satisfied Requirements / Total Requirements × 100
```

------------------------------------------------------------------------

## 16.3 Accuracy

Accuracy uses deterministic pytest results.

``` text
Accuracy =
Passed Tests /
(Passed Tests + Failed Tests + Errors)
× 100
```

This avoids using an LLM to judge deterministic software behavior.

------------------------------------------------------------------------

## 16.4 Completeness

A requirement is considered complete when evidence exists in:

``` text
Requirement
   ↓
SRS.md
   ↓
Design.md
   ↓
Generated Code
   ↓
Generated Test
```

Test pass/fail is not required for the completeness check itself;
correctness is handled separately.

------------------------------------------------------------------------

## 16.5 Groundedness

The current implementation uses lexical/source evidence.

It evaluates API names, public functions/classes, imports, and related
claims across:

``` text
Requirements
SRS
Design
Tasks
README
Generated Code
```

The current implementation is not a semantic LLM judge. It is intended
to detect unsupported names, APIs, imports, and similar evidence gaps.

------------------------------------------------------------------------

## 16.6 Hallucination Rate

Hallucination rate uses the same source-claim checks as groundedness.

It detects examples such as:

-   invented APIs
-   functions documented but not implemented
-   extra unrequested functionality
-   unsupported libraries/imports

``` text
Hallucination Rate =
Unsupported Claims / Evaluated Claims × 100
```

------------------------------------------------------------------------

## 16.7 Tool Selection Accuracy

The current project does not attach independent external tools to the
CrewAI agents in the same way a browser/search/code-execution agent
would.

Therefore, the evaluation layer treats workflow routing decisions as the
tool/action decision being evaluated.

For example, after pytest:

``` text
Tests Failed + Debug Attempts Available
        ↓
Expected: Debug

Tests Passed OR Maximum Debug Attempts Reached
        ↓
Expected: Finish
```

The actual next recorded event is compared with the expected action.

If a future version attaches explicit tools to agents, this metric can
be extended to compare expected and actual tool choices.

------------------------------------------------------------------------

## 16.8 Tool Call Success Rate

The evaluator records operations during the pipeline, including:

-   CrewAI/LLM calls
-   pytest executions
-   artifact saves
-   Git commits

An operation is successful when it executes without an exception.

A failing pytest result is treated as a test result rather than
automatically being classified as a tool failure.

------------------------------------------------------------------------

## 16.9 Recovery Rate

The existing debugging loop is used.

``` text
Pytest Failure
      ↓
Debugger Agent
      ↓
Code/Test Modification
      ↓
Pytest Again
      ↓
PASS / FAIL
```

``` text
Recovery Rate =
Successfully Recovered Failures /
Recoverable Failures × 100
```

If no recoverable failure occurs, the metric is reported as `N/A` rather
than incorrectly reporting 100%.

------------------------------------------------------------------------

## 16.10 Reliability

Reliability requires repeated runs of the same task.

``` text
Reliability =
Successful Runs / Total Runs × 100
```

Use:

``` bash
--repeat 5
```

or:

``` bash
--repeat 10
```

to produce meaningful repeated-run data.

------------------------------------------------------------------------

## 16.11 P95 Latency

Latency measures the end-to-end pipeline time, including:

-   LLM inference
-   agent orchestration
-   artifact generation
-   pytest
-   debugging/retries
-   final evaluation processing

P95 is the time below which 95% of recorded runs complete.

A single run does not provide a meaningful P95 distribution, so use
repeated runs.

------------------------------------------------------------------------

## 16.12 Cost per Successful Task

Because Ollama is local, there is no direct API bill.

The project estimates cost using:

``` text
Estimated Cost =
Runtime Hours × EVAL_COST_PER_HOUR
+
Tokens / 1000 × EVAL_COST_PER_1K_TOKENS
```

Then:

``` text
Cost per Successful Task =
Total Estimated Cost /
Number of Successful Tasks
```

Token usage comes from available CrewAI usage metrics where available.
If usage information is unavailable, the evaluator may use an estimate
and should mark it accordingly.

------------------------------------------------------------------------

# 17. Evaluation Output

After an evaluated run, results are printed in the terminal and saved as
a PDF.

The default output directory is:

``` text
evaluation_reports/
```

The structure is:

``` text
evaluation_reports/
├── history.jsonl
└── <project_name>/
    └── evaluation_<mode>_<timestamp>.pdf
```

For example:

``` text
evaluation_reports/
├── history.jsonl
└── calculator/
    └── evaluation_create_20261005_113000.pdf
```

------------------------------------------------------------------------

# 18. Evaluation History

Every evaluated `create` or `change` run is stored as one JSON line:

``` text
evaluation_reports/history.jsonl
```

This historical data is used for repeated-run metrics and comparisons.

Inspect it with:

``` bash
cat evaluation_reports/history.jsonl
```

or:

``` bash
less evaluation_reports/history.jsonl
```

------------------------------------------------------------------------

# 19. Skip Evaluation

Evaluation is enabled by default.

To run the original SDLC pipeline without generating an evaluation
report:

``` bash
python main.py create \
    --name calculator \
    --requirements requirements.txt \
    --no-eval
```

Similarly:

``` bash
python main.py change \
    --name calculator \
    --requirements updated_requirements.txt \
    --no-eval
```

Use this only when evaluation is intentionally not required.

------------------------------------------------------------------------

# 20. Demo

The project includes:

``` text
demo/run_demo.py
```

Run:

``` bash
python demo/run_demo.py
```

This demonstrates the create/change workflow with evaluation.

------------------------------------------------------------------------

# 21. Recommended Evaluation Procedure

For a proper evaluation experiment, use the following sequence.

### Step 1 --- Verify the environment

``` bash
conda activate evoforge
```

### Step 2 --- Verify Ollama

``` bash
ollama list
```

### Step 3 --- Run unit tests

``` bash
pytest -q
```

### Step 4 --- Run one baseline task

``` bash
python main.py create \
    --name calculator_eval \
    --requirements "Create a calculator with add, subtract, multiply and divide functions."
```

### Step 5 --- Run repeated evaluation

``` bash
python main.py create \
    --name calculator_eval_repeat \
    --requirements "Create a calculator with add, subtract, multiply and divide functions." \
    --repeat 10
```

### Step 6 --- Inspect reports

``` bash
find evaluation_reports -type f
```

### Step 7 --- Review the PDF

Open:

``` text
evaluation_reports/<project>/evaluation_<mode>_<timestamp>.pdf
```

### Step 8 --- Review historical results

``` bash
cat evaluation_reports/history.jsonl
```

------------------------------------------------------------------------

# 22. Important Evaluation Limitations

The current implementation intentionally avoids fabricating evaluation
results.

Some metrics may be `N/A` when the required evidence does not exist.

Examples:

-   No explicit tool calls → tool-related metrics may be `N/A`
-   No recoverable failure → Recovery Rate is `N/A`
-   Single run → Reliability/P95 are not statistically meaningful
-   No exposed token data → token count may be estimated
-   Local Ollama → cost is estimated rather than an actual API charge

### Groundedness / Hallucination limitation

The current Groundedness and Hallucination implementation uses
**lexical/source checks** rather than a semantic LLM judge.

It can identify things such as:

-   unsupported API names
-   missing generated functions
-   extra libraries
-   unsupported implementation elements

It does not fully determine whether a piece of prose is semantically
correct.

------------------------------------------------------------------------

# 23. Evaluation Design Principle

The evaluation system should not reduce the agent to one composite
score.

The 12 metrics are intentionally kept independent so that different
failure modes remain visible:

``` text
Outcome
  ├── Task Success
  └── Task Completion

Quality
  ├── Accuracy
  ├── Completeness
  ├── Groundedness
  └── Hallucination

Agent Behavior
  ├── Tool Selection
  ├── Tool Call Success
  └── Recovery

Operational Performance
  ├── Reliability
  ├── P95 Latency
  └── Cost per Successful Task
```

------------------------------------------------------------------------

# 24. Quick Command Reference

### Install

``` bash
pip install -r requirements.txt
```

### Run project

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator with add and subtract."
```

### Repeat evaluation

``` bash
python main.py create \
    --name calculator \
    --requirements "Build a calculator with add and subtract." \
    --repeat 10
```

### Apply requirement change

``` bash
python main.py change \
    --name calculator \
    --requirements updated_requirements.txt
```

### Evaluate existing project

``` bash
python main.py evaluate --name calculator
```

### Run tests

``` bash
pytest -q
```

### Start Streamlit

``` bash
streamlit run app.py
```

### Skip evaluation

``` bash
python main.py create \
    --name calculator \
    --requirements requirements.txt \
    --no-eval
```

### Inspect reports

``` bash
find evaluation_reports -type f
```

### Inspect history

``` bash
cat evaluation_reports/history.jsonl
```

------------------------------------------------------------------------

# 25. Summary

EvoForge combines agentic SDLC automation with an evaluation layer that
measures:

-   whether the generated project succeeds
-   how many requirements are completed
-   whether generated functionality is correct
-   whether requested content is complete
-   whether generated artifacts are grounded in the requirements
-   whether unsupported content is produced
-   whether workflow/tool decisions succeed
-   whether failures can be recovered
-   whether repeated runs are reliable
-   how long the complete pipeline takes
-   and the estimated cost of successful outcomes

The evaluation layer is implemented around the existing SDLC pipeline
rather than replacing the agents.

For a first complete evaluation, use:

``` bash
python main.py create \
    --name calculator_eval \
    --requirements "Create a calculator with add, subtract, multiply and divide functions." \
    --repeat 10
```

Then review:

``` text
evaluation_reports/
```

for the generated PDF and historical JSON results.
