# EvoForge

EvoForge is an AI-powered SDLC automation platform that uses CrewAI and
Ollama to automate software development tasks.

## Features

-   Analyze requirements
-   Generate SRS
-   Create software design
-   Plan development tasks
-   Generate code
-   Generate tests
-   Run pytest
-   Automatically debug failures
-   Maintain requirement traceability
-   Manage Git versions
-   Evaluate the AI agent using 12 evaluation metrics

## Requirements

-   Python 3.10+
-   Ollama
-   Git
-   pip

## Installation

Create a Python environment:

``` bash
conda create -n evoforge python=3.11 -y
conda activate evoforge
```

Install dependencies:

``` bash
pip install -r requirements.txt
```

Check Ollama:

``` bash
ollama list
```

## Run the Project

``` bash
python main.py create     --name calculator     --requirements "Create a calculator with add, subtract, multiply and divide functions."
```

The SDLC pipeline and evaluation run automatically.

## Run Evaluation

To run the same task multiple times:

``` bash
python main.py create     --name calculator     --requirements "Create a calculator with add, subtract, multiply and divide functions."     --repeat 5
```

## Evaluation Metrics

The project evaluates:

1.  Task Success Rate
2.  Task Completion Rate
3.  Accuracy
4.  Completeness
5.  Groundedness
6.  Hallucination Rate
7.  Tool Selection Accuracy
8.  Tool Call Success Rate
9.  Recovery Rate
10. Reliability
11. P95 Latency
12. Cost per Successful Task

## Evaluation Reports

Evaluation results are saved automatically in:

``` text
evaluation_reports/
├── history.jsonl
└── <project_name>/
    └── evaluation_<timestamp>.pdf
```

The metrics are also displayed in the terminal.

## Run Tests

``` bash
pytest -q
```

## Run Streamlit UI

``` bash
streamlit run app.py
```

## Evaluate an Existing Project

``` bash
python main.py evaluate --name calculator
```

## Skip Evaluation

To run the SDLC pipeline without evaluation:

``` bash
python main.py create     --name calculator     --requirements "Create a calculator."     --no-eval
```

## Quick Start

``` bash
conda activate evoforge
pip install -r requirements.txt
ollama list

python main.py create     --name calculator     --requirements "Create a calculator with add, subtract, multiply and divide functions."     --repeat 5
```

Then check:

``` text
evaluation_reports/
```
