import os
import sys
import argparse
import json
from config.settings import MODEL_NAME, OLLAMA_BASE_URL, PROJECTS_DIR
from agents.sdlc_crew import SDLCOrchestrator
from core.project_store import ProjectStore
from core.runner import PytestRunner
from evaluation import run_with_evaluation, audit_project

def main():
    parser = argparse.ArgumentParser(description="EvoForge: Agentic AI SDLC Automation Platform")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Create command
    create_parser = subparsers.add_parser("create", help="Create initial project from client requirements")
    create_parser.add_argument("--name", required=True, help="Project name (e.g. calculator_cli)")
    create_parser.add_argument("--requirements", required=True, help="Requirements string or file path")
    create_parser.add_argument("--repeat", type=int, default=1, help="Run the task N times (measures Reliability / P95 latency)")
    create_parser.add_argument("--no-eval", action="store_true", help="Skip the evaluation report")

    # Change command
    change_parser = subparsers.add_parser("change", help="Apply requirement change to existing project")
    change_parser.add_argument("--name", required=True, help="Project name")
    change_parser.add_argument("--requirements", required=True, help="Updated requirements string or file path")
    change_parser.add_argument("--repeat", type=int, default=1, help="Run the task N times (measures Reliability / P95 latency)")
    change_parser.add_argument("--no-eval", action="store_true", help="Skip the evaluation report")

    # Test command
    test_parser = subparsers.add_parser("test", help="Run automated pytest suite for a project")
    test_parser.add_argument("--name", required=True, help="Project name")

    # Evaluate command
    eval_parser = subparsers.add_parser("evaluate", help="Evaluate an already generated project from its saved artifacts (no LLM run)")
    eval_parser.add_argument("--name", required=True, help="Project name")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "evaluate":
        audit_project(args.name)
        return

    orchestrator = SDLCOrchestrator(model_name=MODEL_NAME, base_url=OLLAMA_BASE_URL)

    if args.command == "create":
        req_text = args.requirements
        if os.path.exists(req_text):
            with open(req_text, "r", encoding="utf-8") as f:
                req_text = f.read()
        for i in range(args.repeat):
            print(f"[*] Starting Initial SDLC Generation for Project '{args.name}' (run {i + 1}/{args.repeat})...")
            if args.no_eval:
                res = orchestrator.run_initial_sdlc_pipeline(args.name, req_text)
            else:
                res = run_with_evaluation(orchestrator, "create", args.name, req_text)
            print("\n[+] SDLC Generation Finished!")
            print(json.dumps(res, indent=2))

    elif args.command == "change":
        req_text = args.requirements
        if os.path.exists(req_text):
            with open(req_text, "r", encoding="utf-8") as f:
                req_text = f.read()
        for i in range(args.repeat):
            print(f"[*] Processing Requirement Change for Project '{args.name}' (run {i + 1}/{args.repeat})...")
            if args.no_eval:
                res = orchestrator.run_incremental_requirement_change(args.name, req_text)
            else:
                res = run_with_evaluation(orchestrator, "change", args.name, req_text)
            print("\n[+] Requirement Change Update Finished!")
            print(json.dumps(res, indent=2))

    elif args.command == "test":
        store = ProjectStore(args.name)
        runner = PytestRunner(store.project_dir)
        print(f"[*] Running pytest suite in {store.project_dir}...")
        res = runner.run_tests()
        print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
