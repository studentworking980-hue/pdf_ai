"""Evaluation layer for the EvoForge SDLC pipeline (does not modify the agents)."""
from evaluation.session import run_with_evaluation, audit_project

__all__ = ["run_with_evaluation", "audit_project"]
