"""
Trace collection.

While a pipeline runs, four existing operations are wrapped (and restored afterwards)
so we can record what happened without editing the agents:

    Crew.kickoff              -> kind "llm_crew"      (every agent stage + debugger call)
    PytestRunner.run_tests    -> kind "pytest"
    ProjectStore.save_artifact-> kind "save_artifact"
    GitManager.commit_all     -> kind "git_commit"
"""
import os
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, List

from agents.prompt_templates import AGENT_ROLES

_ROLE_TO_KEY = {info["role"]: key for key, info in AGENT_ROLES.items()}


@dataclass
class Event:
    kind: str                 # llm_crew | pytest | save_artifact | git_commit
    name: str                 # e.g. "debug", "run_tests", "SRS.md"
    ok: bool                  # did the operation itself execute successfully?
    duration: float           # seconds
    detail: Dict[str, Any] = field(default_factory=dict)


class Trace:
    def __init__(self):
        self.events: List[Event] = []
        self.started = None
        self.elapsed = 0.0

    def add(self, kind, name, ok, duration, **detail):
        self.events.append(Event(kind, name, bool(ok), duration, detail))

    @contextmanager
    def instrument(self):
        """Patch the pipeline operations for the duration of the `with` block."""
        undo = []
        self._patch_all(undo)
        self.started = time.perf_counter()
        try:
            yield self
        finally:
            self.elapsed = time.perf_counter() - self.started
            for cls, attr, original in reversed(undo):
                setattr(cls, attr, original)

    # ------------------------------------------------------------------ patches
    def _patch_all(self, undo):
        from core.runner import PytestRunner
        from core.project_store import ProjectStore
        from core.git_manager import GitManager

        self._wrap(PytestRunner, "run_tests", self._pytest_wrapper, undo)
        self._wrap(ProjectStore, "save_artifact", self._save_wrapper, undo)
        self._wrap(GitManager, "commit_all", self._commit_wrapper, undo)
        try:
            from crewai import Crew
            self._wrap(Crew, "kickoff", self._crew_wrapper, undo)
        except ImportError:   # crewai not installed (e.g. unit tests of the metrics)
            pass

    @staticmethod
    def _wrap(cls, attr, factory, undo):
        original = getattr(cls, attr)
        setattr(cls, attr, factory(original))
        undo.append((cls, attr, original))

    def _pytest_wrapper(self, original):
        trace = self

        def run_tests(runner, *args, **kwargs):
            start, ok, res = time.perf_counter(), True, {}
            try:
                res = original(runner, *args, **kwargs)
                ok = bool(res.get("success"))      # pytest ran (a failing test is NOT a tool failure)
                return res
            except Exception:
                ok = False
                raise
            finally:
                trace.add("pytest", "run_tests", ok, time.perf_counter() - start,
                          passed=bool(res.get("passed")), output=res.get("output", ""))
        return run_tests

    def _save_wrapper(self, original):
        trace = self

        def save_artifact(store, filename, content, is_code=False):
            start, ok = time.perf_counter(), False
            try:
                path = original(store, filename, content, is_code)
                ok = bool(path) and os.path.exists(path)
                return path
            finally:
                trace.add("save_artifact", filename, ok, time.perf_counter() - start)
        return save_artifact

    def _commit_wrapper(self, original):
        trace = self

        def commit_all(git_mgr, message):
            start, ok = time.perf_counter(), False
            try:
                sha = original(git_mgr, message)
                ok = git_mgr.repo is not None      # None sha just means "nothing to commit"
                return sha
            finally:
                trace.add("git_commit", message[:40], ok, time.perf_counter() - start)
        return commit_all

    def _crew_wrapper(self, original):
        trace = self

        def kickoff(crew, *args, **kwargs):
            keys = [_ROLE_TO_KEY.get(getattr(a, "role", ""), "agent") for a in getattr(crew, "agents", [])]
            name = "debug" if keys and all(k == "debugger" for k in keys) else "stage[" + ",".join(keys) + "]"
            start, ok, result = time.perf_counter(), True, None
            try:
                result = original(crew, *args, **kwargs)
                return result
            except Exception:
                ok = False
                raise
            finally:
                tin, tout, source = _token_usage(crew, result)
                trace.add("llm_crew", name, ok, time.perf_counter() - start,
                          tokens_in=tin, tokens_out=tout, token_source=source)
        return kickoff


def _get(obj, key):
    if obj is None:
        return 0
    value = obj.get(key) if isinstance(obj, dict) else getattr(obj, key, 0)
    return value or 0


def _token_usage(crew, result):
    """Prefer CrewAI's own usage metrics; fall back to a chars/4 estimate."""
    usage = getattr(result, "token_usage", None) or getattr(crew, "usage_metrics", None)
    tin, tout = _get(usage, "prompt_tokens"), _get(usage, "completion_tokens")
    if tin + tout > 0:
        return int(tin), int(tout), "reported"
    tasks = getattr(crew, "tasks", []) or []
    chars_in = sum(len(getattr(t, "description", "") or "") for t in tasks)
    chars_out = sum(len(getattr(getattr(t, "output", None), "raw", "") or "") for t in tasks)
    return chars_in // 4, chars_out // 4, "estimated"
