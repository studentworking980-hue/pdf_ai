"""Renders one evaluation (terminal text and PDF) from the same data."""
import textwrap

from evaluation.pdf_writer import PDF, GRAY, GREEN, RED

# How each metric is calculated for THIS project (printed in the PDF and documented in EVALUATION.md)
METRIC_HELP = [
    ("Task Success Rate",
     "A task is one pipeline run (create or change). It succeeds when the pipeline finishes without an "
     "exception AND the final pytest run of the generated project passes. = successful tasks / total tasks x 100."),
    ("Task Completion Rate",
     "Requirements are the numbered/bulleted items of the client requirement text. A requirement is satisfied when "
     "the function(s) it names are defined in the generated code, at least one pytest test exercises them, and every "
     "such test passed in the final run. = satisfied requirements / total requirements x 100."),
    ("Accuracy",
     "From the final pytest run: passed results / (passed + failed + errors) x 100. The tests are deterministic "
     "assertions on the generated code, so no judge model is involved."),
    ("Completeness",
     "A requirement is complete when evidence exists in every layer: SRS.md, Design.md, the generated code and a test "
     "that references it (pass/fail is not considered here). = complete requirements / total requirements x 100."),
    ("Groundedness",
     "Claims = API names used as name(...) in Requirements/SRS/Design/Tasks/README, public functions/classes defined in "
     "the code, and third-party imports. Spec claims are supported if the name appears in the client requirements; "
     "README claims if the name is defined in the generated code; code claims if the client asked for them. "
     "= supported claims / evaluated claims x 100."),
    ("Hallucination Rate",
     "Same claims as Groundedness. = unsupported claims / evaluated claims x 100: invented APIs, documented functions "
     "that do not exist, extra unrequested functions or libraries."),
    ("Tool Selection Accuracy",
     "After every pytest run the pipeline must choose its next action: debug (tests failed and fewer than 3 attempts "
     "used) or finish. Expected action is derived from the test result; actual action is the next logged event. "
     "= matching decisions / decisions x 100. The agents have no tools of their own, so this checks the workflow routing."),
    ("Tool Call Success Rate",
     "Every operation recorded during the run (LLM crew calls, pytest executions, artifact saves, git commits). "
     "An operation succeeds if it executed without error; a failing test is a test result, not a tool failure. "
     "= successful operations / total operations x 100."),
    ("Recovery Rate",
     "A recoverable failure is a run whose first pytest execution failed. It is recovered when the debugger loop makes "
     "the final pytest pass. = recovered failures / recoverable failures x 100 (N/A if nothing failed)."),
    ("Reliability",
     "Runs of the same task (same project, mode and requirements) are collected in history.jsonl. "
     "= successful runs / total runs x 100. Repeat the run (--repeat N) to get a meaningful value."),
    ("P95 Latency",
     "End-to-end wall-clock seconds of the whole pipeline run (all LLM stages, tests and debug loop). The 95th "
     "percentile (nearest-rank) is taken over the recorded runs of the same task."),
    ("Cost per Successful Task",
     "Local Ollama has no API bill, so cost is estimated: runtime hours x EVAL_COST_PER_HOUR + tokens/1000 x "
     "EVAL_COST_PER_1K_TOKENS. Tokens come from CrewAI usage metrics, or chars/4 if unavailable. "
     "= total estimated cost / successful tasks."),
]

NOTES = [
    "Groundedness/Hallucination use lexical source checks (names, imports), not a semantic judge: they catch invented "
    "APIs/libraries but not wrong prose. Add an LLM judge later if needed.",
    "The stored traceability graph links nodes by default rules, so requirement evidence is derived from the artifact "
    "contents (SRS, Design, code, tests) instead.",
    "The debugger may edit tests as well as code; compare initial vs final test counts above when judging Accuracy.",
]


# ------------------------------------------------------------------------- shared pieces
def _header_lines(ev):
    r = ev["rec"]
    d = ev["details"]
    return [
        f"Project : {r['project']}    Mode: {r['mode']}    Model: {r['model']}",
        f"Task ID : {r['task_id']}    Run: {r['timestamp']}",
        f"Result  : {'SUCCESS' if r['success'] else 'FAILED'}"
        + (f"  ({r['error']})" if r["error"] else "")
        + f"    Pytest (initial -> final): {d['initial_counts']['passed']}/{d['initial_counts']['total']} -> "
          f"{d['final_counts']['passed']}/{d['final_counts']['total']} passed",
        f"Rates   : ${d['rates']['per_hour']}/hour, ${d['rates']['per_1k_tokens']}/1k tokens (estimated cost for local Ollama)",
    ]


def _history_title(history_n):
    return f"All runs (n={history_n})" if history_n else "History"


def _requirement_table(ev):
    yes, no = ("yes", GREEN), ("NO", RED)
    rows = []
    for i, q in enumerate(ev["details"]["requirements"], 1):
        rows.append([str(i), q["requirement"], *[yes if q[k] else no for k in ("srs", "design", "code", "test", "tests_pass")],
                     ("yes", GREEN) if q["satisfied"] else ("NO", RED)])
    return ["#", "Requirement", "SRS", "Design", "Code", "Test", "Pass", "Satisfied"], rows, [3, 52, 4, 6, 4, 4, 4, 9]


def _unsupported_claims(ev, limit=40):
    bad = [c for c in ev["details"]["claims"] if not c["supported"]]
    return bad[:limit], len(bad)


# ------------------------------------------------------------------------- terminal
def text_table(headers, rows, widths):
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    out = [line]

    def fmt(cells):
        cols = [textwrap.wrap(str(c), w) or [""] for c, w in zip(cells, widths)]
        for i in range(max(len(c) for c in cols)):
            out.append("| " + " | ".join((c[i] if i < len(c) else "").ljust(w) for c, w in zip(cols, widths)) + " |")

    fmt(headers)
    out.append(line)
    for r in rows:
        fmt(r)
    out.append(line)
    return "\n".join(out)


def render_text(ev, history_n):
    rows = ev["rows"]
    table = text_table(["#", "Metric", "This run", _history_title(history_n), "Calculation basis (actual numbers)"],
                       [[r["no"], r["name"], r["this"], r["history"], r["basis"]] for r in rows], [2, 24, 11, 17, 44])
    unsupported, total_bad = _unsupported_claims(ev, 8)
    lines = ["", "=" * 106, " EVOFORGE - AI AGENT EVALUATION RESULTS", "=" * 106, *_header_lines(ev), "", table]
    if unsupported:
        lines += ["", f"Unsupported claims ({total_bad}), first {len(unsupported)}:"]
        lines += [f"  - [{c['artifact']}] {c['claim']}: {c['reason']}" for c in unsupported]
    unsat = [q["requirement"] for q in ev["details"]["requirements"] if not q["satisfied"]]
    if unsat:
        lines += ["", "Requirements not satisfied:"] + [f"  - {textwrap.shorten(q, 95)}" for q in unsat]
    return "\n".join(lines)


# ------------------------------------------------------------------------- PDF
def write_pdf(ev, history_n, path):
    r, d = ev["rec"], ev["details"]
    pdf = PDF("EvoForge AI Agent Evaluation Report")
    pdf.title_block("EvoForge - AI Agent Evaluation Report", f"Generated {r['timestamp']}  |  run {r['run_id']}")
    for line in _header_lines(ev):
        pdf.para(line, 8)

    pdf.heading("1. Metric results")
    pdf.table(["#", "Metric", "This run", _history_title(history_n), "Calculation basis (actual numbers)"],
              [[str(m["no"]), m["name"], m["this"], m["history"], m["basis"]] for m in ev["rows"]],
              [2, 22, 11, 16, 48])
    pdf.para("This run = values of this single run. History = pooled counts over all recorded runs "
             "(Reliability and P95 use runs of the same task only).", 7, GRAY)

    pdf.heading("2. How each metric is calculated for this project")
    for name, text in METRIC_HELP:
        pdf.ensure(36)                    # keep a metric name together with its explanation
        pdf.para(name, 8)
        pdf.para(text, 7.5, GRAY, indent=10)

    pdf.heading("3. Requirement evidence (Task Completion / Completeness)")
    headers, rows, widths = _requirement_table(ev)
    pdf.table(headers, rows, widths)

    pdf.heading("4. Unsupported claims (Groundedness / Hallucination)")
    bad, total_bad = _unsupported_claims(ev)
    if bad:
        pdf.table(["Artifact", "Claim", "Reason"], [[c["artifact"], c["claim"], c["reason"]] for c in bad], [16, 30, 46])
        if total_bad > len(bad):
            pdf.para(f"... and {total_bad - len(bad)} more.", 7, GRAY)
    else:
        pdf.para("None - every evaluated claim is supported." if d["claims"] else "No claims were found to evaluate.", 8)

    pdf.heading("5. Pipeline trace (Tool metrics, Latency, Cost)")
    kind_rows = [[k, str(v[0]), str(v[1]), str(v[0] - v[1])] for k, v in sorted(d["kinds"].items())]
    pdf.table(["Operation", "Calls", "Succeeded", "Failed"], kind_rows or [["(no trace - audit mode)", "-", "-", "-"]], [20, 8, 10, 8])
    if d["stages"]:
        pdf.table(["LLM crew call", "Seconds", "Tokens in", "Tokens out", "OK"],
                  [[s["name"], f"{s['seconds']:.1f}", str(s["tin"]), str(s["tout"]), "yes" if s["ok"] else "NO"] for s in d["stages"]],
                  [44, 8, 10, 10, 4])
    if d["decisions"]:
        pdf.table(["Decision (after pytest run)", "Expected", "Actual"],
                  [[str(i), x["expected"], (x["actual"], GREEN if x["actual"] == x["expected"] else RED)] for i, x in enumerate(d["decisions"], 1)],
                  [26, 10, 10])

    pdf.heading("6. Notes and limitations")
    for note in NOTES:
        pdf.para("- " + note, 7.5, GRAY)
    pdf.save(path)
    return path
