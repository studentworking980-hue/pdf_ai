"""
Tiny dependency-free PDF writer (text + tables only).

Uses the built-in PDF fonts (Courier for body/tables, Helvetica-Bold for headings), so no
font files and no third-party package are needed. Courier is monospaced, which makes
line-wrapping exact: characters per line = available width / (0.6 * font size).
"""
import os
import textwrap
import unicodedata

BLACK, GRAY, GREEN, RED, HEAD = (0, 0, 0), (0.45, 0.45, 0.45), (0.05, 0.5, 0.2), (0.75, 0.1, 0.1), (0.88, 0.9, 0.95)


def _clean(s):
    """ASCII-only, PDF-string-escaped."""
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "replace").decode("ascii")
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


class PDF:
    W, H, M = 595.28, 841.89, 40.0          # A4 in points, margin

    def __init__(self, title):
        self.title = title
        self.pages = []
        self.y = 0.0
        self.new_page()

    # ---------------------------------------------------------------- low level
    def new_page(self):
        self.pages.append([])
        self.y = self.H - self.M

    def _put(self, op):
        self.pages[-1].append(op)

    def text(self, x, y, s, font="F1", size=8, color=BLACK):
        self._put("BT /%s %.1f Tf %.2f %.2f %.2f rg %.2f %.2f Td (%s) Tj ET" % (font, size, *color, x, y, _clean(s)))

    def rect(self, x, y, w, h, fill=None):
        if fill:
            self._put("%.2f %.2f %.2f rg %.2f %.2f %.2f %.2f re f" % (*fill, x, y, w, h))
        self._put("0.6 G 0.4 w %.2f %.2f %.2f %.2f re S" % (x, y, w, h))

    def ensure(self, height):
        if self.y - height < self.M + 14:
            self.new_page()

    # ---------------------------------------------------------------- flow helpers
    def title_block(self, title, subtitle):
        self.text(self.M, self.y - 16, title, "F3", 16)
        self.text(self.M, self.y - 30, subtitle, "F1", 8, GRAY)
        self.y -= 44

    def heading(self, s):
        self.ensure(40)
        self.y -= 10
        self.text(self.M, self.y - 10, s, "F3", 11)
        self.y -= 16

    def para(self, s, size=8, color=BLACK, indent=0.0):
        width = int((self.W - 2 * self.M - indent) / (0.6 * size))
        for line in textwrap.wrap(str(s), width=width) or [""]:
            self.ensure(size * 1.4)
            self.text(self.M + indent, self.y - size, line, "F1", size, color)
            self.y -= size * 1.4

    def table(self, headers, rows, widths, size=7.5):
        """widths = characters per column. A cell is a string or (string, color)."""
        cw, pad, lh = 0.6 * size, 3.0, size * 1.35
        usable = self.W - 2 * self.M
        px = [w * cw + 2 * pad for w in widths]
        if sum(px) > usable:                               # shrink last column to fit the page
            px[-1] -= sum(px) - usable
            widths = list(widths)
            widths[-1] = int((px[-1] - 2 * pad) / cw)

        def draw(cells, bold=False, fill=None):
            wrapped, colors = [], []
            for cell, w in zip(cells, widths):
                text, color = cell if isinstance(cell, tuple) else (cell, BLACK)
                wrapped.append(textwrap.wrap(str(text), width=w, break_long_words=True) or [""])
                colors.append(color)
            height = max(len(c) for c in wrapped) * lh + 2 * pad
            if self.y - height < self.M + 14:
                self.new_page()
                draw(headers, bold=True, fill=HEAD)         # repeat header on the new page
            x = self.M
            for lines, w, color in zip(wrapped, px, colors):
                self.rect(x, self.y - height, w, height, fill)
                for i, line in enumerate(lines):
                    self.text(x + pad, self.y - pad - size - i * lh + 1, line, "F2" if bold else "F1", size, color)
                x += w
            self.y -= height

        draw(headers, bold=True, fill=HEAD)
        for row in rows:
            draw(row)
        self.y -= 4

    # ---------------------------------------------------------------- output
    def save(self, path):
        n = len(self.pages)
        for i, ops in enumerate(self.pages):                # footer on every page
            ops.append("BT /F1 7 Tf 0.45 0.45 0.45 rg %.2f 22 Td (%s) Tj ET" % (self.M, _clean(f"{self.title}  -  page {i + 1}/{n}")))
        fonts = ["Courier", "Courier-Bold", "Helvetica-Bold"]
        objs = ["<< /Type /Catalog /Pages 2 0 R >>",
                "<< /Type /Pages /Kids [%s] /Count %d >>" % (" ".join("%d 0 R" % (6 + 2 * i) for i in range(n)), n)]
        objs += ["<< /Type /Font /Subtype /Type1 /BaseFont /%s /Encoding /WinAnsiEncoding >>" % f for f in fonts]
        for i, ops in enumerate(self.pages):
            stream = "\n".join(ops)
            objs.append("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Contents %d 0 R "
                        "/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> >>" % (self.W, self.H, 7 + 2 * i))
            objs.append("<< /Length %d >>\nstream\n%s\nendstream" % (len(stream), stream))
        objs.append("<< /Title (%s) /Producer (EvoForge evaluation) >>" % _clean(self.title))

        out, offsets = bytearray(b"%PDF-1.4\n"), []
        for i, body in enumerate(objs, 1):
            offsets.append(len(out))
            out += b"%d 0 obj\n" % i + body.encode("latin-1") + b"\nendobj\n"
        xref = len(out)
        out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
        for off in offsets:
            out += b"%010d 00000 n \n" % off
        out += b"trailer\n<< /Size %d /Root 1 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, len(objs), xref)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "wb") as f:
            f.write(out)
