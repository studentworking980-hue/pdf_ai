"""
Glue code: run the (unchanged) pipeline under a trace, evaluate the outcome,
print the results, save the PDF and append the run to history.
"""
import json
import os
import traceback

from config.settings import (EVAL_COST_PER_1K_TOKENS, EVAL_COST_PER_HOUR, EVAL_DIR,
                             MODEL_NAME, PROJECTS_DIR)
from core.project_store import ProjectStore
from core.runner import PytestRunner
from evaluation import metrics, report
from evaluation.tracer import Trace

LAST = {}   # last evaluation (text, pdf_path, record) - used by the Streamlit app


def _history_path():
    return os.path.join(os.path.abspath(EVAL_DIR), "history.jsonl")


def load_history():
    path = _history_path()
    if not os.path.exists(path):
        return []
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                try:
                    records.append(json.loads(line))
                except ValueError:
                    pass          # ignore a corrupted line
    return records


def _append_history(rec):
    os.makedirs(os.path.dirname(_history_path()), exist_ok=True)
    with open(_history_path(), "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")


def _collect_artifacts(project_name):
    store = ProjectStore(project_name)
    meta = store.load_metadata()
    module = project_name.lower().replace("-", "_")
    main_file = meta.get("main_file", f"{module}.py")
    test_file = meta.get("test_file", f"test_{main_file}")
    doc = lambda name: store.read_artifact(name) or ""
    return {
        "requirements": doc("Requirements.md"), "srs": doc("SRS.md"), "design": doc("Design.md"),
        "tasks": doc("Tasks.md"), "readme": doc("README.md"),
        "code": store.read_artifact(main_file, is_code=True) or "",
        "tests": store.read_artifact(test_file, is_code=True) or "",
        "module": main_file[:-3] if main_file.endswith(".py") else main_file,
    }


def _finish(mode, project, requirements_text, trace, error, quiet):
    """Evaluate, print, save PDF, record history. Never raises: evaluation must not break the pipeline."""
    try:
        rates = {"per_hour": EVAL_COST_PER_HOUR, "per_1k_tokens": EVAL_COST_PER_1K_TOKENS}
        ev = metrics.evaluate_run(mode=mode, project=project, requirements_text=requirements_text,
                                  art=_collect_artifacts(project), events=trace.events, elapsed=trace.elapsed,
                                  error=error, model=MODEL_NAME, rates=rates)
        rec = ev["rec"]
        history = [] if mode == "audit" else load_history() + [rec]
        ev["rows"] = metrics.build_rows(rec, history)

        pdf_path = os.path.join(os.path.abspath(EVAL_DIR), project, f"evaluation_{mode}_{rec['run_id']}.pdf")
        text = report.render_text(ev, len(history))
        report.write_pdf(ev, len(history), pdf_path)
        if mode != "audit":
            _append_history(rec)

        LAST.clear()
        LAST.update({"text": text, "pdf_path": pdf_path, "record": rec})
        if not quiet:
            print(text)
            print(f"\n[Evaluation] PDF report saved: {pdf_path}")
            print(f"[Evaluation] History: {_history_path()}" if mode != "audit" else "[Evaluation] Audit run - not added to history.")
    except Exception:
        print("\n[Evaluation Warning] Could not compute the evaluation report:")
        traceback.print_exc()


def run_with_evaluation(orchestrator, mode, project_name, requirements_text, quiet=False):
    """
    Runs the normal pipeline and evaluates it. Returns exactly what the pipeline returns
    (and re-raises the pipeline's exception, after still producing a report).
      mode = "create" -> orchestrator.run_initial_sdlc_pipeline
      mode = "change" -> orchestrator.run_incremental_requirement_change
    """
    pipeline = {"create": orchestrator.run_initial_sdlc_pipeline,
                "change": orchestrator.run_incremental_requirement_change}[mode]
    trace, error, result = Trace(), None, None
    with trace.instrument():
        try:
            result = pipeline(project_name, requirements_text)
        except Exception as exc:
            error = exc
    _finish(mode, project_name, requirements_text, trace, error, quiet)
    if error is not None:
        raise error
    return result


def audit_project(project_name, quiet=False):
    """
    Evaluate an already generated project from its saved artifacts (no LLM, no pipeline run).
    Pytest is executed now; trajectory metrics (tools, recovery, latency, cost, reliability) are N/A.
    """
    if not os.path.isdir(os.path.join(PROJECTS_DIR, project_name)):
        raise FileNotFoundError(f"Project '{project_name}' not found in '{PROJECTS_DIR}'.")
    meta = ProjectStore(project_name).load_metadata()
    if not meta.get("requirements"):
        raise ValueError(f"No saved requirements for '{project_name}' (reports/{project_name}/metadata.json).")
    trace = Trace()
    with trace.instrument():
        PytestRunner(ProjectStore(project_name).project_dir).run_tests()
    _finish("audit", project_name, meta["requirements"], trace, None, quiet)
    return LAST.get("record")
