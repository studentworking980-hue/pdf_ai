"""
Metric calculations for the EvoForge SDLC pipeline.

Everything here is computed from real run data (trace events, generated artifacts,
pytest output). Nothing is hard-coded and no LLM is needed. Pure standard library.
"""
import ast
import builtins
import hashlib
import keyword
import math
import re
import sys
from datetime import datetime

MAX_DEBUG_ATTEMPTS = 3   # mirrors the debug loop limit in agents/sdlc_crew.py

STOPWORDS = set(
    "that this with from have must should shall will when then than into over each "
    "also only both such they them their there where which while using used uses "
    "return returns returned value values input output system module function functions".split()
)
IGNORED_NAMES = set(dir(builtins)) | set(keyword.kwlist)   # print(), len(), ValueError(), ...


# ----------------------------------------------------------------------------- text helpers
def _stem(w):
    return w[:-1] if len(w) > 3 and w.endswith("s") else w


def words_of(text):
    """Lower-cased, lightly stemmed word set (snake_case/camelCase are split)."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", text or "")
    return {_stem(w) for w in re.findall(r"[a-z0-9]+", spaced.lower())}


def has_name(name, words):
    """True if every part of an identifier (add_task -> add, task) occurs in `words`."""
    parts = [_stem(p) for p in re.findall(r"[a-z0-9]+", re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", name).lower())]
    return bool(parts) and all(p in words for p in parts)


def has_exact(name, text):
    return re.search(rf"\b{re.escape(name)}\b", text or "") is not None


def call_names(text):
    """Ordered unique identifiers used like name( ... ), minus builtins/keywords/test helpers/attributes."""
    seen = []
    for name in re.findall(r"(?<![\w.])([A-Za-z_]\w*)\(", text or ""):
        if name not in IGNORED_NAMES and not name.startswith("test") and name not in seen:
            seen.append(name)
    return seen


def exception_names(text):
    return sorted(set(re.findall(r"\b([A-Z]\w*(?:Error|Exception))\b", text or "")))


def keywords(text):
    return {_stem(w) for w in re.findall(r"[a-z]{4,}", (text or "").lower())} - STOPWORDS


def overlap_ok(kw, words, threshold=0.5):
    return bool(kw) and len(kw & words) / len(kw) >= threshold


def parse_requirements(text):
    """Numbered / bulleted lines are requirements; otherwise one per line (or sentence)."""
    items = []
    for line in (text or "").splitlines():
        m = re.match(r"\s*(?:\d+[.)]|[-*\u2022])\s+(.*\S)", line)
        if m:
            items.append(m.group(1))
    if items:
        return items
    parts = [l.strip() for l in (text or "").splitlines() if l.strip()]
    if len(parts) == 1:
        parts = re.split(r"(?<=[.!?])\s+", parts[0])
    return [p for p in parts if p]


# ----------------------------------------------------------------------------- code / pytest analysis
def analyze_code(src):
    info = {"parsed": True, "defined": set(), "public": [], "imports": set()}
    try:
        tree = ast.parse(src or "")
    except SyntaxError:
        info["parsed"] = False
        return info
    defs = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
    for node in ast.walk(tree):
        if isinstance(node, defs):
            info["defined"].add(node.name)
        elif isinstance(node, ast.Import):
            info["imports"].update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            info["imports"].add(node.module.split(".")[0])
    info["public"] = [n.name for n in tree.body if isinstance(n, defs) and not n.name.startswith("_")]
    return info


def analyze_tests(src):
    """{test_function_name: set of names it references}"""
    refs = {}
    try:
        tree = ast.parse(src or "")
    except SyntaxError:
        return refs
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
            names = set()
            for n in ast.walk(node):
                if isinstance(n, ast.Name):
                    names.add(n.id)
                elif isinstance(n, ast.Attribute):
                    names.add(n.attr)
            refs[node.name] = names
    return refs


def parse_pytest(output):
    """-> ({test_function: passed?}, {'passed': n, 'failed': n, 'error': n, 'total': n})"""
    outcomes = {}
    for m in re.finditer(r"^(\S+::\S+)\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)", output or "", re.M):
        func = m.group(1).split("::")[-1].split("[")[0]
        outcomes[func] = outcomes.get(func, True) and m.group(2) == "PASSED"
    counts = {"passed": 0, "failed": 0, "error": 0}
    for line in reversed((output or "").splitlines()):
        if re.search(r"\bin [\d.]+s\b", line) or "no tests ran" in line:
            for n, word in re.findall(r"(\d+) (passed|failed|errors?)", line):
                counts["error" if word.startswith("error") else word] += int(n)
            break
    counts["total"] = counts["passed"] + counts["failed"] + counts["error"]
    return outcomes, counts


# ----------------------------------------------------------------------------- requirement evidence
def check_requirements(client_text, art, outcomes, suite_passed):
    """One evidence row per client requirement (used by Task Completion + Completeness)."""
    code, tests = analyze_code(art["code"]), analyze_tests(art["tests"])
    srs_w, design_w = words_of(art["srs"]), words_of(art["design"])
    code_w, test_w = words_of(art["code"]), words_of(art["tests"])
    rows = []
    for text in parse_requirements(client_text):
        funcs, excs = call_names(text), exception_names(text)
        if funcs or excs:
            in_srs = all(has_name(f, srs_w) for f in funcs) and all(has_exact(e, art["srs"]) for e in excs)
            in_design = all(has_name(f, design_w) for f in funcs) and all(has_exact(e, art["design"]) for e in excs)
            in_code = all(f in code["defined"] for f in funcs) and all(has_exact(e, art["code"]) for e in excs)
            covering = {t for t, names in tests.items() if any(f in names for f in funcs)} if funcs else set(tests)
            has_test = (bool(covering)
                        and all(any(f in names for names in tests.values()) for f in funcs)
                        and all(has_exact(e, art["tests"]) for e in excs))
            tests_pass = has_test and all(outcomes.get(t, False) for t in covering)
        else:   # no function names in the requirement: fall back to keyword overlap
            kw = keywords(text)
            in_srs, in_design = overlap_ok(kw, srs_w), overlap_ok(kw, design_w)
            in_code, has_test = overlap_ok(kw, code_w), overlap_ok(kw, test_w)
            tests_pass = has_test and suite_passed
        rows.append({
            "requirement": text, "terms": funcs + excs,
            "srs": in_srs, "design": in_design, "code": in_code, "test": has_test,
            "tests_pass": tests_pass,
            "satisfied": in_code and has_test and tests_pass,    # Task Completion
            "complete": in_srs and in_design and in_code and has_test,   # Completeness
        })
    return rows


# ----------------------------------------------------------------------------- claims (groundedness)
def check_claims(client_text, art):
    """
    Claims are checked against source artifacts with simple, explainable rules:
      Requirements/SRS/Design/Tasks: every API name used as name(...) must appear in the client requirements
      README.md                    : every API name used as name(...) must be defined in the generated code
      Generated code               : every public function/class must have been requested by the client
                                     every third-party import must be mentioned by the client
    """
    client_w = words_of(client_text)
    code = analyze_code(art["code"])
    claims = []

    def add(artifact, claim, ok, why_ok, why_not):
        claims.append({"artifact": artifact, "claim": claim, "supported": ok, "reason": why_ok if ok else why_not})

    for label, key in (("Requirements.md", "requirements"), ("SRS.md", "srs"),
                       ("Design.md", "design"), ("Tasks.md", "tasks")):
        for name in call_names(art[key]):
            add(label, f"API {name}()", has_name(name, client_w),
                "named in client requirements", "not in client requirements")
    for name in call_names(art["readme"]):
        add("README.md", f"API {name}()", name in code["defined"],
            "defined in generated code", "not defined in generated code")
    for name in code["public"]:
        add("code", f"defines {name}", has_name(name, client_w),
            "requested by client", "not requested by client")
    stdlib = getattr(sys, "stdlib_module_names", set())
    for mod in sorted(code["imports"]):
        if mod in stdlib or mod in ("pytest", art["module"]):
            continue
        add("code", f"imports {mod}", mod.lower() in client_w,
            "mentioned by client", "third-party library not mentioned by client")
    return claims


# ----------------------------------------------------------------------------- routing decisions
def routing_decisions(events):
    """After each pytest run the pipeline must pick 'debug' (tests failed, attempts left) or 'finish'."""
    decisions, attempts = [], 0
    for i, ev in enumerate(events):
        if ev.kind != "pytest":
            continue
        expected = "debug" if (not ev.detail.get("passed") and attempts < MAX_DEBUG_ATTEMPTS) else "finish"
        nxt = next((e for e in events[i + 1:] if e.kind in ("pytest", "llm_crew")), None)
        actual = "finish" if nxt is None or nxt.kind == "pytest" else ("debug" if nxt.name == "debug" else "other")
        attempts += actual == "debug"
        decisions.append({"expected": expected, "actual": actual})
    return decisions


# ----------------------------------------------------------------------------- one run -> record
def evaluate_run(*, mode, project, requirements_text, art, events, elapsed, error, model, rates):
    """
    Returns {"rec": flat dict stored in history, "details": extra tables for the report}.
    mode: 'create' | 'change' | 'audit'  (audit = artifacts only, no pipeline trace)
    """
    audit = mode == "audit"
    pytests = [e for e in events if e.kind == "pytest"]
    first, final = (pytests[0], pytests[-1]) if pytests else (None, None)
    outcomes, counts = parse_pytest(final.detail["output"]) if final else ({}, {"passed": 0, "failed": 0, "error": 0, "total": 0})
    _, first_counts = parse_pytest(first.detail["output"]) if first else ({}, counts)
    suite_passed = bool(final and final.detail.get("passed"))
    success = error is None and suite_passed

    reqs = check_requirements(requirements_text, art, outcomes, suite_passed)
    claims = check_claims(requirements_text, art)

    llm = [e for e in events if e.kind == "llm_crew"]
    tin, tout = sum(e.detail["tokens_in"] for e in llm), sum(e.detail["tokens_out"] for e in llm)
    sources = {e.detail["token_source"] for e in llm}
    token_source = "reported" if sources == {"reported"} else "estimated" if sources == {"estimated"} else "mixed" if sources else "none"
    decisions = routing_decisions(events)
    debug_attempts = sum(1 for e in llm if e.name == "debug")
    initial_failed = bool(first and not first.detail.get("passed"))
    cost = elapsed / 3600 * rates["per_hour"] + (tin + tout) / 1000 * rates["per_1k_tokens"]

    rec = {
        "run_id": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "task_id": f"{mode}:{project}:{hashlib.sha1((requirements_text or '').strip().encode()).hexdigest()[:8]}",
        "mode": mode, "project": project, "model": model,
        "success": int(success), "error": str(error) if error else None,
        "req_total": len(reqs), "req_satisfied": sum(r["satisfied"] for r in reqs),
        "req_complete": sum(r["complete"] for r in reqs),
        "tests_total": counts["total"], "tests_passed": counts["passed"],
        "claims_total": len(claims), "claims_supported": sum(c["supported"] for c in claims),
        # trajectory-based values are None for an audit (no pipeline was traced)
        "tool_total": None if audit else len(events), "tool_ok": None if audit else sum(e.ok for e in events),
        "sel_total": None if audit else len(decisions),
        "sel_ok": None if audit else sum(d["expected"] == d["actual"] for d in decisions),
        "recoverable": None if audit else int(initial_failed),
        "recovered": None if audit else int(initial_failed and success),
        "debug_attempts": None if audit else debug_attempts,
        "latency_s": None if audit else round(elapsed, 3),
        "tokens_in": None if audit else tin, "tokens_out": None if audit else tout,
        "token_source": token_source, "cost": None if audit else round(cost, 6),
    }
    kinds = {}
    for e in events:
        k = kinds.setdefault(e.kind, [0, 0])
        k[0] += 1
        k[1] += e.ok
    details = {
        "requirements": reqs, "claims": claims, "decisions": decisions, "kinds": kinds,
        "stages": [{"name": e.name, "seconds": e.duration, "tin": e.detail["tokens_in"],
                    "tout": e.detail["tokens_out"], "ok": e.ok} for e in llm],
        "initial_counts": first_counts, "final_counts": counts, "rates": rates,
    }
    return {"rec": rec, "details": details}


# ----------------------------------------------------------------------------- aggregation + rows
def percentile95(values):
    """Nearest-rank 95th percentile."""
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(0.95 * len(ordered)) - 1)]


def _sum(records, key):
    vals = [r[key] for r in records if r.get(key) is not None]
    return sum(vals) if vals else None


def _pct(num, den):
    return None if not den else 100.0 * num / den


def _fmt(value, suffix="%"):
    return "N/A" if value is None else f"{value:.1f}{suffix}"


def build_rows(rec, history):
    """
    12 metric rows. `history` = all recorded runs including this one (empty for an audit).
    'This run' uses this run's numbers; 'History' pools the counts of all recorded runs.
    """
    def pooled(num_key, den_key, invert=False):
        num, den = _sum(history, num_key), _sum(history, den_key)
        if not den:
            return "N/A"
        if invert:
            num = den - num
        return f"{_fmt(_pct(num, den))} ({int(num)}/{int(den)})"

    def this(num, den, invert=False):
        if not den:
            return "N/A"
        return _fmt(100.0 * (den - num) / den if invert else 100.0 * num / den)

    r = rec
    audit = r["mode"] == "audit"
    same_task = [h for h in history if h["task_id"] == r["task_id"]]
    n_same, ok_same = len(same_task), sum(h["success"] for h in same_task)
    lat = [h["latency_s"] for h in same_task if h.get("latency_s") is not None]
    p95 = percentile95(lat)
    succ_all = _sum(history, "success")
    cost_all = _sum(history, "cost")
    na = "N/A (audit: no pipeline trace)"

    rows = []

    def row(name, this_v, hist_v, basis):
        rows.append({"no": len(rows) + 1, "name": name, "this": this_v, "history": hist_v, "basis": basis})

    row("Task Success Rate", _fmt(100.0 * r["success"]), _task_success(history),
        "pipeline finished + final pytest passed" if r["success"] else f"FAILED: {r['error'] or 'final pytest did not pass'}")
    row("Task Completion Rate", this(r["req_satisfied"], r["req_total"]), pooled("req_satisfied", "req_total"),
        f"{r['req_satisfied']}/{r['req_total']} requirements implemented and verified by passing tests")
    row("Accuracy", this(r["tests_passed"], r["tests_total"]), pooled("tests_passed", "tests_total"),
        f"{r['tests_passed']}/{r['tests_total']} pytest results correct (final run)")
    row("Completeness", this(r["req_complete"], r["req_total"]), pooled("req_complete", "req_total"),
        f"{r['req_complete']}/{r['req_total']} requirements with SRS+design+code+test evidence")
    row("Groundedness", this(r["claims_supported"], r["claims_total"]), pooled("claims_supported", "claims_total"),
        f"{r['claims_supported']}/{r['claims_total']} claims supported by source artifacts")
    row("Hallucination Rate", this(r["claims_supported"], r["claims_total"], invert=True),
        pooled("claims_supported", "claims_total", invert=True),
        f"{r['claims_total'] - r['claims_supported']}/{r['claims_total']} claims unsupported")
    if audit:
        for name in ("Tool Selection Accuracy", "Tool Call Success Rate", "Recovery Rate"):
            row(name, "N/A", "N/A", na)
        row("Reliability", "N/A", "N/A", na)
        row("P95 Latency", "N/A", "N/A", na)
        row("Cost per Successful Task", "N/A", "N/A", na)
        return rows

    row("Tool Selection Accuracy", this(r["sel_ok"], r["sel_total"]), pooled("sel_ok", "sel_total"),
        f"{r['sel_ok']}/{r['sel_total']} routing decisions matched the expected action")
    row("Tool Call Success Rate", this(r["tool_ok"], r["tool_total"]), pooled("tool_ok", "tool_total"),
        f"{r['tool_ok']}/{r['tool_total']} operations succeeded (LLM calls, pytest, saves, commits)")
    if r["recoverable"]:
        basis = f"initial pytest failed; {r['debug_attempts']} debug attempt(s); " + ("recovered" if r["recovered"] else "NOT recovered")
    else:
        basis = "initial pytest passed - no failure to recover"
    row("Recovery Rate", this(r["recovered"], r["recoverable"]), pooled("recovered", "recoverable"), basis)
    row("Reliability", "-", f"{_fmt(_pct(ok_same, n_same))} ({ok_same}/{n_same})",
        f"{n_same} recorded run(s) of this task" + (" - repeat the run for a meaningful value" if n_same < 2 else ""))
    row("P95 Latency", f"{r['latency_s']:.1f}s", "N/A" if p95 is None else f"{p95:.1f}s",
        f"end-to-end seconds; P95 over {len(lat)} run(s) of this task" + (" (equals the max when n<20)" if len(lat) < 20 else ""))
    cps = r["cost"] if r["success"] else None
    hist_cps = None if not succ_all else (cost_all or 0.0) / succ_all
    row("Cost per Successful Task", "N/A (failed)" if cps is None else f"${cps:.4f}",
        "N/A" if hist_cps is None else f"${hist_cps:.4f}",
        f"est. cost ${r['cost']:.4f}; {r['tokens_in'] + r['tokens_out']} tokens ({r['token_source']})")
    return rows


def _task_success(history):
    den = len(history)
    return "N/A" if not den else f"{_fmt(_pct(sum(h['success'] for h in history), den))} ({sum(h['success'] for h in history)}/{den})"
