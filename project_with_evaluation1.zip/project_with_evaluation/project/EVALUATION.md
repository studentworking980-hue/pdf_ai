# EvoForge - AI Agent Evaluation

An evaluation layer around the existing SDLC pipeline. It records what the pipeline actually did
(LLM calls, pytest runs, debug attempts, timing, tokens), reads the generated artifacts, and computes
12 metrics. **The agents and pipeline logic are unchanged**; the layer wraps four existing operations
(`Crew.kickoff`, `PytestRunner.run_tests`, `ProjectStore.save_artifact`, `GitManager.commit_all`) while a run is
in progress and restores them afterwards. No new dependencies (the PDF is written by a small built-in writer).

## Run

Setup is unchanged (`pip install -r requirements.txt`, Ollama running). Evaluation happens automatically:

```bash
# 1. Generate a project  -> metrics printed in the terminal + PDF saved
python main.py create --name calculator --requirements "Build a calculator.
1. add(a, b): Returns the sum.
2. subtract(a, b): Returns a minus b.
3. multiply(a, b): Returns the product.
4. divide(a, b): Returns the quotient. Raise ValueError if b is 0."

# 2. Apply a requirement change (evaluated the same way)
python main.py change --name calculator --requirements updated_requirements.txt

# 3. Repeat a task N times: this is what makes Reliability and P95 Latency meaningful
python main.py create --name calculator --requirements reqs.txt --repeat 5

# 4. Evaluate an already generated project from its saved files (no LLM run)
python main.py evaluate --name demo_calculator

# Other entry points are evaluated too
python demo/run_demo.py          # create + change, one report each
streamlit run app.py             # report shown in the app, with a PDF download button

# Skip the evaluation for one run
python main.py create --name x --requirements reqs.txt --no-eval

# Unit tests (include the evaluation layer; no LLM needed)
pytest
```

## Output

| What | Where |
|---|---|
| Terminal results | printed at the end of every run |
| PDF report | `evaluation_reports/<project>/evaluation_<mode>_<timestamp>.pdf` |
| Run history (one JSON line per run) | `evaluation_reports/history.jsonl` |

Every table has a **This run** column and an **All runs** column (counts pooled over `history.jsonl`).
`evaluate` runs are audits: they are not added to history, and the metrics that need a pipeline trace
(tools, recovery, latency, cost, reliability) show `N/A`.

## How each metric is calculated here

A *task* = one pipeline run (`create` or `change`). Nothing is hard-coded; every value comes from the run.

| # | Metric | Calculation for this project |
|---|---|---|
| 1 | **Task Success Rate** | A task is one pipeline run (create or change). It succeeds when the pipeline finishes without an exception AND the final pytest run of the generated project passes. = successful tasks / total tasks x 100. |
| 2 | **Task Completion Rate** | Requirements are the numbered/bulleted items of the client requirement text. A requirement is satisfied when the function(s) it names are defined in the generated code, at least one pytest test exercises them, and every such test passed in the final run. = satisfied requirements / total requirements x 100. |
| 3 | **Accuracy** | From the final pytest run: passed results / (passed + failed + errors) x 100. The tests are deterministic assertions on the generated code, so no judge model is involved. |
| 4 | **Completeness** | A requirement is complete when evidence exists in every layer: SRS.md, Design.md, the generated code and a test that references it (pass/fail is not considered here). = complete requirements / total requirements x 100. |
| 5 | **Groundedness** | Claims = API names used as name(...) in Requirements/SRS/Design/Tasks/README, public functions/classes defined in the code, and third-party imports. Spec claims are supported if the name appears in the client requirements; README claims if the name is defined in the generated code; code claims if the client asked for them. = supported claims / evaluated claims x 100. |
| 6 | **Hallucination Rate** | Same claims as Groundedness. = unsupported claims / evaluated claims x 100: invented APIs, documented functions that do not exist, extra unrequested functions or libraries. |
| 7 | **Tool Selection Accuracy** | After every pytest run the pipeline must choose its next action: debug (tests failed and fewer than 3 attempts used) or finish. Expected action is derived from the test result; actual action is the next logged event. = matching decisions / decisions x 100. The agents have no tools of their own, so this checks the workflow routing. |
| 8 | **Tool Call Success Rate** | Every operation recorded during the run (LLM crew calls, pytest executions, artifact saves, git commits). An operation succeeds if it executed without error; a failing test is a test result, not a tool failure. = successful operations / total operations x 100. |
| 9 | **Recovery Rate** | A recoverable failure is a run whose first pytest execution failed. It is recovered when the debugger loop makes the final pytest pass. = recovered failures / recoverable failures x 100 (N/A if nothing failed). |
| 10 | **Reliability** | Runs of the same task (same project, mode and requirements) are collected in history.jsonl. = successful runs / total runs x 100. Repeat the run (--repeat N) to get a meaningful value. |
| 11 | **P95 Latency** | End-to-end wall-clock seconds of the whole pipeline run (all LLM stages, tests and debug loop). The 95th percentile (nearest-rank) is taken over the recorded runs of the same task. |
| 12 | **Cost per Successful Task** | Local Ollama has no API bill, so cost is estimated: runtime hours x EVAL_COST_PER_HOUR + tokens/1000 x EVAL_COST_PER_1K_TOKENS. Tokens come from CrewAI usage metrics, or chars/4 if unavailable. = total estimated cost / successful tasks. |

## Configuration (optional, `.env`)

```
EVAL_DIR=evaluation_reports
EVAL_COST_PER_HOUR=0.50          # assumed cost of the local machine, USD/hour
EVAL_COST_PER_1K_TOKENS=0.0      # optional per-token component
```
Cost is an **estimate** (local Ollama has no API bill). Change the rates to match your hardware.

## Files

```
evaluation/
  tracer.py      wraps the 4 pipeline operations and records events (calls, results, timing, tokens)
  metrics.py     all metric calculations (pure functions, standard library only)
  report.py      terminal table + PDF content, and the metric explanations above
  pdf_writer.py  ~100-line dependency-free PDF writer
  session.py     run_with_evaluation(), audit_project(), history file handling
tests/test_evaluation.py
```

## Limitations

- Groundedness/Hallucination use lexical source checks (names, imports), not a semantic judge: they catch invented APIs/libraries but not wrong prose. Add an LLM judge later if needed.
- The stored traceability graph links nodes by default rules, so requirement evidence is derived from the artifact contents (SRS, Design, code, tests) instead.
- The debugger may edit tests as well as code; compare initial vs final test counts above when judging Accuracy.
- Reliability and P95 only become meaningful after several runs of the same task (`--repeat N`).
- Token counts come from CrewAI usage metrics when Ollama reports them; otherwise they are estimated (marked `estimated`/`mixed`).
