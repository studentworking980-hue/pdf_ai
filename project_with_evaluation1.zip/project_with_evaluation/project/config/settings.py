import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

MODEL_NAME = os.getenv("MODEL_NAME", "llama3.2:latest")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
PROJECTS_DIR = os.getenv("PROJECTS_DIR", "projects")
REPORTS_DIR = os.getenv("REPORTS_DIR", "reports")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# ---- Evaluation layer (see EVALUATION.md) ----
EVAL_DIR = os.getenv("EVAL_DIR", "evaluation_reports")
# Local Ollama has no API bill, so cost is an ESTIMATE built from these rates:
#   cost = runtime_hours * EVAL_COST_PER_HOUR + total_tokens / 1000 * EVAL_COST_PER_1K_TOKENS
EVAL_COST_PER_HOUR = float(os.getenv("EVAL_COST_PER_HOUR", "0.50"))
EVAL_COST_PER_1K_TOKENS = float(os.getenv("EVAL_COST_PER_1K_TOKENS", "0.0"))
