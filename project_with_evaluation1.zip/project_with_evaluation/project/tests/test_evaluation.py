"""Unit tests for the evaluation layer. They use small synthetic runs: no LLM, no crewai."""
from evaluation import metrics
from evaluation.pdf_writer import PDF
from evaluation.tracer import Event

REQ = ("Build a calculator.\n"
       "1. add(a, b): Returns the sum.\n"
       "2. divide(a, b): Raise ValueError if b is 0.\n")

CODE = ("import math\n"
        "def add(a, b):\n    return a + b\n"
        "def divide(a, b):\n    if b == 0:\n        raise ValueError('x')\n    return a / b\n"
        "def extra():\n    pass\n")
TESTS = ("import pytest\nfrom calc import add, divide\n"
         "def test_add():\n    assert add(1, 2) == 3\n"
         "def test_divide_zero():\n    with pytest.raises(ValueError):\n        divide(1, 0)\n")
ART = {"requirements": "1. add(a, b)\n2. divide(a, b)\n3. sqrt(x)", "srs": "add(a, b) and divide(a, b) raise ValueError",
       "design": "add divide ValueError", "tasks": "write add(a, b)", "readme": "use add(1, 2) or modulo(1, 2)",
       "code": CODE, "tests": TESTS, "module": "calc"}
PYTEST_OK = ("calc.py::test_add PASSED [ 50%]\ncalc.py::test_divide_zero PASSED [100%]\n"
             "============ 2 passed in 0.01s ============")
PYTEST_BAD = ("calc.py::test_add PASSED [ 50%]\ncalc.py::test_divide_zero FAILED [100%]\n"
              "============ 1 failed, 1 passed in 0.01s ============")
RATES = {"per_hour": 3600.0, "per_1k_tokens": 1.0}   # 1 $/second keeps the cost arithmetic obvious


def ev(kind, name="x", ok=True, **detail):
    return Event(kind, name, ok, 0.1, detail)


def test_parse_requirements_numbered_and_fallback():
    assert metrics.parse_requirements(REQ) == ["add(a, b): Returns the sum.", "divide(a, b): Raise ValueError if b is 0."]
    assert metrics.parse_requirements("Build a todo app. It must store tasks.") == ["Build a todo app.", "It must store tasks."]


def test_parse_pytest_counts_and_outcomes():
    outcomes, counts = metrics.parse_pytest(PYTEST_BAD)
    assert outcomes == {"test_add": True, "test_divide_zero": False}
    assert (counts["passed"], counts["failed"], counts["total"]) == (1, 1, 2)
    assert metrics.parse_pytest("=== 1 error in 0.1s ===")[1]["total"] == 1
    assert metrics.parse_pytest("")[1]["total"] == 0


def test_requirement_evidence():
    outcomes, _ = metrics.parse_pytest(PYTEST_OK)
    rows = metrics.check_requirements(REQ, ART, outcomes, True)
    assert [r["satisfied"] for r in rows] == [True, True]
    assert all(r["complete"] for r in rows)
    # a failing covering test means the requirement is not satisfied, but it is still "complete" (evidence exists)
    outcomes, _ = metrics.parse_pytest(PYTEST_BAD)
    rows = metrics.check_requirements(REQ, ART, outcomes, False)
    assert [r["satisfied"] for r in rows] == [True, False]
    assert rows[1]["complete"]
    # missing function in code -> not satisfied
    rows = metrics.check_requirements(REQ + "3. power(a, b): power.\n", ART, outcomes, True)
    assert rows[2]["code"] is False and rows[2]["satisfied"] is False


def test_claims_detect_unsupported_names():
    claims = metrics.check_claims(REQ, ART)
    bad = {(c["artifact"], c["claim"]) for c in claims if not c["supported"]}
    assert ("Requirements.md", "API sqrt()") in bad            # invented requirement API
    assert ("README.md", "API modulo()") in bad                 # documented but not in code
    assert ("code", "defines extra") in bad                     # unrequested public function
    assert ("code", "imports math") not in {(c["artifact"], c["claim"]) for c in claims}   # stdlib is not a claim
    assert ("SRS.md", "API add()") not in bad


def test_routing_decisions():
    ok = [ev("pytest", passed=False), ev("llm_crew", "debug"), ev("pytest", passed=True)]
    assert [(d["expected"], d["actual"]) for d in metrics.routing_decisions(ok)] == [("debug", "debug"), ("finish", "finish")]
    skipped_debug = [ev("pytest", passed=False)]               # failed, attempts left, but pipeline stopped
    d = metrics.routing_decisions(skipped_debug)[0]
    assert d["expected"] != d["actual"]


def test_percentile95_nearest_rank():
    assert metrics.percentile95([]) is None
    assert metrics.percentile95([5.0]) == 5.0
    assert metrics.percentile95(list(range(1, 101))) == 95


def _run(events, elapsed=2.0, error=None):
    return metrics.evaluate_run(mode="create", project="calc", requirements_text=REQ, art=ART, events=events,
                                elapsed=elapsed, error=error, model="m", rates=RATES)


def test_evaluate_run_recovery_cost_and_rows():
    events = [ev("llm_crew", "stage[a]", tokens_in=1000, tokens_out=1000, token_source="reported"),
              ev("pytest", passed=False, output=PYTEST_BAD), ev("llm_crew", "debug", tokens_in=500, tokens_out=500, token_source="reported"),
              ev("save_artifact", "calc.py"), ev("pytest", passed=True, output=PYTEST_OK)]
    rec = _run(events)["rec"]
    assert rec["success"] == 1 and rec["recoverable"] == 1 and rec["recovered"] == 1 and rec["debug_attempts"] == 1
    assert rec["tool_total"] == 5 and rec["tool_ok"] == 5 and rec["sel_ok"] == rec["sel_total"] == 2
    assert rec["tests_total"] == 2 and rec["tests_passed"] == 2
    assert abs(rec["cost"] - (2.0 + 3.0)) < 1e-9               # 2 s * $1/s + 3k tokens * $1/1k
    rows = {r["name"]: r for r in metrics.build_rows(rec, [rec])}
    assert len(rows) == 12
    assert rows["Task Success Rate"]["this"] == "100.0%"
    assert rows["Recovery Rate"]["this"] == "100.0%"
    assert rows["Cost per Successful Task"]["this"] == "$5.0000"


def test_failed_run_and_history_pooling():
    good = _run([ev("pytest", passed=True, output=PYTEST_OK)])["rec"]
    bad = _run([ev("pytest", passed=False, output=PYTEST_BAD)], error=None)["rec"]
    assert bad["success"] == 0 and bad["recoverable"] == 1 and bad["recovered"] == 0
    rows = {r["name"]: r for r in metrics.build_rows(bad, [good, bad])}
    assert rows["Task Success Rate"]["this"] == "0.0%"
    assert rows["Task Success Rate"]["history"] == "50.0% (1/2)"
    assert rows["Reliability"]["history"].startswith("50.0%")
    assert rows["Cost per Successful Task"]["this"].startswith("N/A")


def test_audit_mode_marks_trajectory_metrics_na():
    ev_ = metrics.evaluate_run(mode="audit", project="calc", requirements_text=REQ, art=ART,
                               events=[ev("pytest", passed=True, output=PYTEST_OK)], elapsed=1.0, error=None, model="m", rates=RATES)
    rows = {r["name"]: r for r in metrics.build_rows(ev_["rec"], [])}
    assert rows["Accuracy"]["this"] == "100.0%"
    assert all(rows[n]["this"] == "N/A" for n in ("Tool Call Success Rate", "Recovery Rate", "P95 Latency"))


def test_pdf_writer_creates_valid_file(tmp_path):
    pdf = PDF("t")
    pdf.heading("Heading (with) parens \\ and unicode \u2713")
    pdf.table(["a", "b"], [["x" * 200, ("ok", (0, 0.5, 0))]] * 60, [10, 20])      # forces wrapping + a page break
    out = tmp_path / "r.pdf"
    pdf.save(str(out))
    data = out.read_bytes()
    assert data.startswith(b"%PDF-1.4") and data.rstrip().endswith(b"%%EOF")
    assert len(pdf.pages) > 1
