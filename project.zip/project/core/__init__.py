# Core package initialization
