import os
import sys
import argparse
import json
from config.settings import MODEL_NAME, OLLAMA_BASE_URL, PROJECTS_DIR
from agents.sdlc_crew import SDLCOrchestrator
from core.project_store import ProjectStore
from core.runner import PytestRunner

def main():
    parser = argparse.ArgumentParser(description="EvoForge: Agentic AI SDLC Automation Platform")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Create command
    create_parser = subparsers.add_parser("create", help="Create initial project from client requirements")
    create_parser.add_argument("--name", required=True, help="Project name (e.g. calculator_cli)")
    create_parser.add_argument("--requirements", required=True, help="Requirements string or file path")

    # Change command
    change_parser = subparsers.add_parser("change", help="Apply requirement change to existing project")
    change_parser.add_argument("--name", required=True, help="Project name")
    change_parser.add_argument("--requirements", required=True, help="Updated requirements string or file path")

    # Test command
    test_parser = subparsers.add_parser("test", help="Run automated pytest suite for a project")
    test_parser.add_argument("--name", required=True, help="Project name")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    orchestrator = SDLCOrchestrator(model_name=MODEL_NAME, base_url=OLLAMA_BASE_URL)

    if args.command == "create":
        req_text = args.requirements
        if os.path.exists(req_text):
            with open(req_text, "r", encoding="utf-8") as f:
                req_text = f.read()
        print(f"[*] Starting Initial SDLC Generation for Project '{args.name}'...")
        res = orchestrator.run_initial_sdlc_pipeline(args.name, req_text)
        print("\n[+] SDLC Generation Finished!")
        print(json.dumps(res, indent=2))

    elif args.command == "change":
        req_text = args.requirements
        if os.path.exists(req_text):
            with open(req_text, "r", encoding="utf-8") as f:
                req_text = f.read()
        print(f"[*] Processing Requirement Change for Project '{args.name}'...")
        res = orchestrator.run_incremental_requirement_change(args.name, req_text)
        print("\n[+] Requirement Change Update Finished!")
        print(json.dumps(res, indent=2))

    elif args.command == "test":
        store = ProjectStore(args.name)
        runner = PytestRunner(store.project_dir)
        print(f"[*] Running pytest suite in {store.project_dir}...")
        res = runner.run_tests()
        print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
